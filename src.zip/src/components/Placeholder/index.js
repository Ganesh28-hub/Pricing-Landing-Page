import React, { Component } from 'react';

/**
 * @author Leo Fajardo
 */
class Placeholder extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <div className="fs-placeholder"></div>;
  }
}

export default Placeholder;
