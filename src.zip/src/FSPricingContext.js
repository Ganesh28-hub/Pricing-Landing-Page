import React from 'react';

const FSPricingContext = React.createContext({});

export default FSPricingContext;
